Certainly! Here's an example of C++ code that builds a binary search tree with the least search cost based on the access probabilities for each key:

```cpp
#include <iostream>
#include <vector>

// Structure for BST Node
struct Node {
    int key;
    Node* left;
    Node* right;

    Node(int k) : key(k), left(nullptr), right(nullptr) {}
};

// Function to build optimal binary search tree
Node* buildOptimalBST(const std::vector<int>& keys, const std::vector<double>& probabilities) {
    int n = keys.size();

    // Create cost and root tables
    std::vector<std::vector<double>> cost(n + 1, std::vector<double>(n + 1, 0.0));
    std::vector<std::vector<int>> root(n + 1, std::vector<int>(n + 1, 0));

    // Initialize cost table with probabilities
    for (int i = 1; i <= n; ++i)
        cost[i][i] = probabilities[i - 1];

    // Fill cost and root tables
    for (int length = 2; length <= n; ++length) {
        for (int i = 1; i <= n - length + 1; ++i) {
            int j = i + length - 1;
            cost[i][j] = INT_MAX;

            // Calculate cost for each possible root
            for (int k = i; k <= j; ++k) {
                double currentCost = cost[i][k - 1] + cost[k + 1][j];
                if (currentCost < cost[i][j]) {
                    cost[i][j] = currentCost;
                    root[i][j] = k;
                }
            }

            // Add the access probabilities of keys within the range
            for (int k = i; k <= j; ++k)
                cost[i][j] += probabilities[k - 1];
        }
    }

    // Build the optimal BST using root table
    return buildBST(keys, root, 1, n);
}

// Helper function to build the BST recursively
Node* buildBST(const std::vector<int>& keys, const std::vector<std::vector<int>>& root, int start, int end) {
    if (start > end)
        return nullptr;

    int rootIndex = root[start][end];
    Node* newNode = new Node(keys[rootIndex - 1]);

    newNode->left = buildBST(keys, root, start, rootIndex - 1);
    newNode->right = buildBST(keys, root, rootIndex + 1, end);

    return newNode;
}

// Function to print inorder traversal of BST
void inorderTraversal(Node* root) {
    if (root) {
        inorderTraversal(root->left);
        std::cout << root->key << " ";
        inorderTraversal(root->right);
    }
}

int main() {
    std::vector<int> keys = {1, 2, 3, 4, 5};
    std::vector<double> probabilities = {0.15, 0.10, 0.05, 0.10, 0.20};

    Node* root = buildOptimalBST(keys, probabilities);

    std::cout << "Inorder Traversal of Optimal BST: ";
    inorderTraversal(root);
    std::cout << std::endl;

    return 0;
}
```

In this code, we define a `Node` structure to represent each node of the binary search tree. The `buildOptimalBST` function takes in the sorted keys and their corresponding access probabilities and returns the root of the optimal binary

 search tree. It utilizes the cost and root tables to determine the optimal structure of the BST. The `buildBST` helper function recursively builds the BST based on the root table. Finally, the `inorderTraversal` function is used to print the inorder traversal of the constructed BST.

Please note that this is a basic implementation of the algorithm, and additional error handling and optimizations can be added as per your specific requirements.