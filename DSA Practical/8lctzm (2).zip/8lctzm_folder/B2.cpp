#include <iostream>

class TreeNode {
public:
    int data;
    TreeNode* left;
    TreeNode* right;

    TreeNode(int value) : data(value), left(nullptr), right(nullptr) {}
};

class BinarySearchTree {
private:
    TreeNode* root;

    TreeNode* insertNode(TreeNode* node, int value) {
        if (node == nullptr) {
            return new TreeNode(value);
        }

        if (value < node->data) {
            node->left = insertNode(node->left, value);
        } else {
            node->right = insertNode(node->right, value);
        }

        return node;
    }

    int findMaxDepth(TreeNode* node) {
        if (node == nullptr) {
            return 0;
        }

        int leftDepth = findMaxDepth(node->left);
        int rightDepth = findMaxDepth(node->right);

        return 1 + std::max(leftDepth, rightDepth);
    }

    int findMinValue(TreeNode* node) {
        if (node->left == nullptr) {
            return node->data;
        }

        return findMinValue(node->left);
    }

    void swapChildren(TreeNode* node) {
        if (node == nullptr) {
            return;
        }

        TreeNode* temp = node->left;
        node->left = node->right;
        node->right = temp;

        swapChildren(node->left);
        swapChildren(node->right);
    }

    bool searchValue(TreeNode* node, int value) {
        if (node == nullptr) {
            return false;
        }

        if (value == node->data) {
            return true;
        } else if (value < node->data) {
            return searchValue(node->left, value);
        } else {
            return searchValue(node->right, value);
        }
    }

public:
    BinarySearchTree() : root(nullptr) {}

    void insert(int value) {
        root = insertNode(root, value);
    }

    int getLongestPath() {
        return findMaxDepth(root);
    }

    int getMinValue() {
        return findMinValue(root);
    }

    void swapChildren() {
        swapChildren(root);
    }

    bool search(int value) {
        return searchValue(root, value);
    }
};

int main() {
    BinarySearchTree bst;

    // Insert nodes
    bst.insert(8);
    bst.insert(3);
    bst.insert(10);
    bst.insert(1);
    bst.insert(6);
    bst.insert(4);
    bst.insert(7);
    bst.insert(14);
    bst.insert(13);

    // Insert new node
    bst.insert(5);

    // Find number of nodes in longest path from root
    int longestPath = bst.getLongestPath();
    std::cout << "Number of nodes in the longest path from root: " << longestPath << std::endl;

    // Minimum data value found in the tree
    int minValue = bst.getMinValue();
    std::cout << "Minimum value in the tree: " << minValue << std::endl;

    // Change the tree by swapping left and right pointers at every node
    bst.swapChildren();

    // Search a value
    int valueToSearch = 10;
    bool found = bst.search(valueToSearch);
    std::cout << "Value " << valueToSearch << " is " << (found ? "found" : "not found") << std::endl;

    return 0;
}
