#include <iostream>

class TreeNode {
public:
    int data;
    TreeNode* left;
    TreeNode* right;
    bool isThreaded;

    TreeNode(int value) : data(value), left(nullptr), right(nullptr), isThreaded(false) {}
};

class ThreadedBinaryTree {
private:
    TreeNode* root;
    TreeNode* prev;

    void convertToThreaded(TreeNode* node) {
        if (node == nullptr) {
            return;
        }

        convertToThreaded(node->left);

        if (node->left == nullptr) {
            node->left = prev;
            node->isThreaded = true;
        }

        if (prev != nullptr && prev->right == nullptr) {
            prev->right = node;
            prev->isThreaded = true;
        }

        prev = node;

        convertToThreaded(node->right);
    }

    TreeNode* findInorderSuccessor(TreeNode* node) {
        if (node == nullptr) {
            return nullptr;
        }

        if (node->isThreaded) {
            return node->right;
        }

        if (node->right != nullptr) {
            return findLeftmost(node->right);
        }

        while (node != nullptr && !node->isThreaded) {
            node = node->right;
        }

        return node;
    }

    TreeNode* findLeftmost(TreeNode* node) {
        if (node == nullptr) {
            return nullptr;
        }

        while (node->left != nullptr) {
            node = node->left;
        }

        return node;
    }

public:
    ThreadedBinaryTree() : root(nullptr), prev(nullptr) {}

    void convertToThreaded() {
        convertToThreaded(root);
    }

    TreeNode* getRoot() {
        return root;
    }

    TreeNode* getInorderSuccessor(TreeNode* node) {
        return findInorderSuccessor(node);
    }
};

int main() {
    // Construct a binary tree
    ThreadedBinaryTree tbt;
    tbt.root = new TreeNode(1);
    tbt.root->left = new TreeNode(2);
    tbt.root->right = new TreeNode(3);
    tbt.root->left->left = new TreeNode(4);
    tbt.root->left->right = new TreeNode(5);
    tbt.root->right->left = new TreeNode(6);
    tbt.root->right->right = new TreeNode(7);

    // Convert to threaded binary tree
    tbt.convertToThreaded();

    // Test the threaded binary tree by printing inorder traversal using inorder successor
    TreeNode* current = tbt.findLeftmost(tbt.getRoot());
    while (current != nullptr) {
        std::cout << current->data << " ";
        current = tbt.getInorderSuccessor(current);
    }
    std::cout << std::endl;

    return 0;
}
