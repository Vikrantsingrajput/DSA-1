#include <iostream>
#include <vector>

class TreeNode {
public:
    std::string data;
    std::vector<TreeNode*> children;

    TreeNode(std::string value) : data(value) {}

    void addChild(TreeNode* child) {
        children.push_back(child);
    }
};

void printTree(TreeNode* node, int level = 0) {
    for (int i = 0; i < level; ++i) {
        std::cout << "  ";
    }
    std::cout << node->data << std::endl;

    for (TreeNode* child : node->children) {
        printTree(child, level + 1);
    }
}

int main() {
    // Construct the book structure

    TreeNode* book = new TreeNode("Book");

    // Add chapters
    TreeNode* chapter1 = new TreeNode("Chapter 1");
    TreeNode* chapter2 = new TreeNode("Chapter 2");
    TreeNode* chapter3 = new TreeNode("Chapter 3");

    book->addChild(chapter1);
    book->addChild(chapter2);
    book->addChild(chapter3);

    // Add sections to Chapter 1
    TreeNode* section11 = new TreeNode("Section 1.1");
    TreeNode* section12 = new TreeNode("Section 1.2");

    chapter1->addChild(section11);
    chapter1->addChild(section12);

    // Add subsections to Section 1.1
    TreeNode* subsection111 = new TreeNode("Subsection 1.1.1");
    TreeNode* subsection112 = new TreeNode("Subsection 1.1.2");

    section11->addChild(subsection111);
    section11->addChild(subsection112);

    // Print the book structure
    printTree(book);

    // Clean up memory (delete nodes)
    delete book;
    delete chapter1;
    delete chapter2;
    delete chapter3;
    delete section11;
    delete section12;
    delete subsection111;
    delete subsection112;

    return 0;
}
