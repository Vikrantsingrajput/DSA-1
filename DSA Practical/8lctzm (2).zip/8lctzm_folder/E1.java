import java.util.Arrays;

public class SortAlgorithms {
    // Implementation of Heap Sort
    public static void heapSort(int[] arr) {
        int n = arr.length;

        // Build the max heap
        for (int i = n / 2 - 1; i >= 0; i--)
            heapify(arr, n, i);

        // Extract elements from the heap one by one
        for (int i = n - 1; i > 0; i--) {
            // Swap the root (max element) with the last element
            int temp = arr[0];
            arr[0] = arr[i];
            arr[i] = temp;

            // Heapify the reduced heap
            heapify(arr, i, 0);
        }
    }

    private static void heapify(int[] arr, int n, int i) {
        int largest = i;
        int left = 2 * i + 1;
        int right = 2 * i + 2;

        // If the left child is larger than the root
        if (left < n && arr[left] > arr[largest])
            largest = left;

        // If the right child is larger than the largest so far
        if (right < n && arr[right] > arr[largest])
            largest = right;

        // If the largest element is not the root
        if (largest != i) {
            // Swap the largest element with the root
            int temp = arr[i];
            arr[i] = arr[largest];
            arr[largest] = temp;

            // Recursively heapify the affected sub-tree
            heapify(arr, n, largest);
        }
    }

    // Implementation of Shell Sort
    public static void shellSort(int[] arr) {
        int n = arr.length;

        // Start with a large gap and reduce it over time
        for (int gap = n / 2; gap > 0; gap /= 2) {
            // Perform insertion sort within the gap
            for (int i = gap; i < n; i++) {
                int temp = arr[i];
                int j;

                // Shift elements that are greater than temp to the right
                for (j = i; j >= gap && arr[j - gap] > temp; j -= gap)
                    arr[j] = arr[j - gap];

                // Insert the current element into the correct position
                arr[j] = temp;
            }
        }
    }

    public static void main(String[] args) {
        int[] arr = { 9, 5, 7, 1, 3 };

        System.out.println("Original Array: " + Arrays.toString(arr));

        // Perform Heap Sort
        heapSort(arr);
        System.out.println("Sorted Array (Heap Sort): " + Arrays.toString(arr));

        // Perform Shell Sort
        shellSort(arr);
        System.out.println("Sorted Array (Shell Sort): " + Arrays.toString(arr));
    }
}
