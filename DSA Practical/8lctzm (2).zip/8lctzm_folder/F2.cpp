#include <iostream>
#include <fstream>
#include <string>

struct Employee {
    int employeeID;
    std::string name;
    std::string designation;
    double salary;
};

const int INDEX_SIZE = 100;

// Function to add a new employee record
void addEmployee(std::fstream& file, std::fstream& indexFile) {
    Employee employee;

    std::cout << "Enter Employee ID: ";
    std::cin >> employee.employeeID;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

    std::cout << "Enter Name: ";
    std::getline(std::cin, employee.name);

    std::cout << "Enter Designation: ";
    std::getline(std::cin, employee.designation);

    std::cout << "Enter Salary: ";
    std::cin >> employee.salary;

    // Write the employee record to the file
    file.seekp(0, std::ios::end);
    std::streampos recordPos = file.tellp();
    file.write(reinterpret_cast<const char*>(&employee), sizeof(Employee));

    // Write the index record to the index file
    indexFile.seekp(employee.employeeID * sizeof(std::streampos));
    indexFile.write(reinterpret_cast<const char*>(&recordPos), sizeof(std::streampos));

    std::cout << "Employee record added successfully." << std::endl;
}

// Function to delete an employee record
void deleteEmployee(std::fstream& file, std::fstream& indexFile) {
    int employeeID;
    bool found = false;

    std::cout << "Enter Employee ID of employee to delete: ";
    std::cin >> employeeID;

    // Read the index record from the index file
    std::streampos recordPos;
    indexFile.seekg(employeeID * sizeof(std::streampos));
    indexFile.read(reinterpret_cast<char*>(&recordPos), sizeof(std::streampos));

    if (recordPos != -1) {
        // Delete the employee record by marking it as invalid
        Employee employee;
        file.seekp(recordPos);
        file.write(reinterpret_cast<const char*>(&employee), sizeof(Employee));

        // Mark the index record as invalid
        recordPos = -1;
        indexFile.seekp(employeeID * sizeof(std::streampos));
        indexFile.write(reinterpret_cast<const char*>(&recordPos), sizeof(std::streampos));

        found = true;
        std::cout << "Employee record deleted successfully." << std::endl;
    } else {
        std::cout << "Employee record not found." << std::endl;
    }
}

// Function to display the details of an employee
void displayEmployee(std::fstream& file, std::fstream& indexFile) {
    int employeeID;
    bool found = false;

    std::cout << "Enter Employee ID of employee to display: ";
    std::cin >> employeeID;

    // Read the index record from the index file
    std::streampos recordPos;
    indexFile.seekg(employeeID * sizeof(std::streampos));
    indexFile.read(reinterpret_cast<char*>(&recordPos), sizeof(std::streampos));

    if (recordPos != -1) {
        // Read and display the employee record
        Employee employee;
        file.seekg(recordPos);
        file.read(reinterpret_cast<char*>(&employee), sizeof(Employee));

        std::cout << "Employee Details:" << std::endl;
        std::cout << "Employee ID: " << employee.employeeID << std::endl;
        std::cout << "Name: " << employee.name << std::endl;
        std::cout << "Designation: " << employee.designation << std::endl;
        std::cout << "Salary: " << employee.salary << std::endl;

        found = true;
    }

    if (!found) {
        std::cout << "Employee record not found." << std::endl;
    }
}

int main() {
    std::fstream file("employees.dat", std::ios::in | std::ios::out | std::ios::binary);
    std::fstream indexFile("index.dat", std::ios::in | std::ios::out | std::ios::binary);

    if (!file || !indexFile) {
        std::cerr << "Error opening files." << std::endl;
        return 1;
    }

    int choice;
    do {
        std::cout << "----- Employee Information System -----" << std::endl;
        std::cout << "1. Add Employee" << std::endl;
        std::cout << "2. Delete Employee" << std::endl;
        std::cout << "3. Display Employee Details" << std::endl;
        std::cout << "4. Quit" << std::endl;
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                addEmployee(file, indexFile);
                break;
            case 2:
                deleteEmployee(file, indexFile);
                break;
            case 3:
                displayEmployee(file, indexFile);
                break;
            case 4:
                std::cout << "Quitting..." << std::endl;
                break;
            default:
                std::cout << "Invalid choice. Please try again." << std::endl;
                break;
        }

        std::cout << std::endl;
    } while (choice != 4);

    // Close the files
    file.close();
    indexFile.close();

    return 0;
}
