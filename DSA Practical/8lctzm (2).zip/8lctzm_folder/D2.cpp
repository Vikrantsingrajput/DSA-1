#include <iostream>
#include <string>
#include <algorithm>

// Structure for AVL Tree Node
struct Node {
    std::string keyword;
    std::string meaning;
    int height;
    Node* left;
    Node* right;

    Node(const std::string& key, const std::string& val)
        : keyword(key), meaning(val), height(1), left(nullptr), right(nullptr) {}
};

// Function to get the height of a node
int getHeight(Node* node) {
    if (node == nullptr)
        return 0;
    return node->height;
}

// Function to get the balance factor of a node
int getBalanceFactor(Node* node) {
    if (node == nullptr)
        return 0;
    return getHeight(node->left) - getHeight(node->right);
}

// Function to update the height of a node
void updateHeight(Node* node) {
    if (node == nullptr)
        return;
    node->height = std::max(getHeight(node->left), getHeight(node->right)) + 1;
}

// Function to perform a right rotation
Node* rotateRight(Node* node) {
    Node* newRoot = node->left;
    Node* temp = newRoot->right;

    newRoot->right = node;
    node->left = temp;

    updateHeight(node);
    updateHeight(newRoot);

    return newRoot;
}

// Function to perform a left rotation
Node* rotateLeft(Node* node) {
    Node* newRoot = node->right;
    Node* temp = newRoot->left;

    newRoot->left = node;
    node->right = temp;

    updateHeight(node);
    updateHeight(newRoot);

    return newRoot;
}

// Function to balance the AVL tree
Node* balanceTree(Node* node) {
    if (node == nullptr)
        return nullptr;

    updateHeight(node);

    int balanceFactor = getBalanceFactor(node);

    // Left Left Case
    if (balanceFactor > 1 && getBalanceFactor(node->left) >= 0)
        return rotateRight(node);

    // Left Right Case
    if (balanceFactor > 1 && getBalanceFactor(node->left) < 0) {
        node->left = rotateLeft(node->left);
        return rotateRight(node);
    }

    // Right Right Case
    if (balanceFactor < -1 && getBalanceFactor(node->right) <= 0)
        return rotateLeft(node);

    // Right Left Case
    if (balanceFactor < -1 && getBalanceFactor(node->right) > 0) {
        node->right = rotateRight(node->right);
        return rotateLeft(node);
    }

    return node;
}

// Function to insert a keyword and its meaning into the AVL tree
Node* insert(Node* node, const std::string& keyword, const std::string& meaning) {
    if (node == nullptr)
        return new Node(keyword, meaning);

    if (keyword < node->keyword)
        node->left = insert(node->left, keyword, meaning);
    else if (keyword > node->keyword)
        node->right = insert(node->right, keyword, meaning);
    else {
        // Keyword already exists, update the meaning
        node->meaning = meaning;
        return node;
    }

    return balanceTree(node);
}

// Function to find the node with minimum keyword value in an AVL tree
Node* findMin(Node* node) {
    if (node == nullptr)
        return nullptr;
    while (node->left != nullptr)
        node = node->left;
    return node;
}

// Function to delete a keyword from the AVL tree
Node* remove(Node* node, const std::string& keyword) {
    if (node == nullptr)
        return nullptr;

    if (keyword < node->keyword)
        node->left = remove(node->left, keyword);
    else if (keyword > node->keyword)
        node->right = remove(node->right, keyword);
    else {
        // Node to be deleted found

        if (node->left == nullptr && node->right == nullptr) {
            // Case 1: Node is a leaf node
            delete node;
            return nullptr;
        } else if (node->left == nullptr || node->right == nullptr) {
            // Case 2: Node has only one child
            Node* temp = (node->left != nullptr) ? node->left : node->right;
            delete node;
            return temp;
        } else {
            // Case 3: Node has two children
            Node* successor = findMin(node->right);
            node->keyword = successor->keyword;
            node->meaning = successor->meaning;
            node->right = remove(node->right, successor->keyword);
        }
    }

    return balanceTree(node);
}

// Function to update the meaning of a keyword in the AVL tree
void update(Node* node, const std::string& keyword, const std::string& meaning) {
    if (node == nullptr)
        return;

    if (keyword < node->keyword)
        update(node->left, keyword, meaning);
    else if (keyword > node->keyword)
        update(node->right, keyword, meaning);
    else {
        // Keyword found, update the meaning
        node->meaning = meaning;
    }
}

// Function to perform inorder traversal and display the data in ascending order
void inorderTraversal(Node* node) {
    if (node == nullptr)
        return;

    inorderTraversal(node->left);
    std::cout << "Keyword: " << node->keyword << ", Meaning: " << node->meaning << std::endl;
    inorderTraversal(node->right);
}

// Function to perform reverse inorder traversal and display the data in descending order
void reverseInorderTraversal(Node* node) {
    if (node == nullptr)
        return;

    reverseInorderTraversal(node->right);
    std::cout << "Keyword: " << node->keyword << ", Meaning: " << node->meaning << std::endl;
    reverseInorderTraversal(node->left);
}

// Function to find the maximum comparisons required for finding a keyword
int findMaxComparisons(Node* node, const std::string& keyword, int comparisons) {
    if (node == nullptr)
        return comparisons;

    if (keyword < node->keyword)
        return findMaxComparisons(node->left, keyword, comparisons + 1);
    else if (keyword > node->keyword)
        return findMaxComparisons(node->right, keyword, comparisons + 1);
    else
        return comparisons + 1; // Keyword found
}

int main() {
    Node* root = nullptr;

    // Add new keywords
    root = insert(root, "apple", "A fruit");
    root = insert(root, "banana", "A fruit");
    root = insert(root, "car", "A vehicle");

    // Display the data in ascending order
    std::cout << "Ascending Order:" << std::endl;
    inorderTraversal(root);

    // Display the data in descending order
    std::cout << "Descending Order:" << std::endl;
    reverseInorderTraversal(root);

    // Update the meaning of a keyword
    update(root, "car", "A four-wheeled vehicle");

    // Display the updated data in ascending order
    std::cout << "Ascending Order (After Update):" << std::endl;
    inorderTraversal(root);

    // Find the maximum comparisons required for finding a keyword
    int maxComparisons = findMaxComparisons(root, "banana", 0);
    std::cout << "Maximum Comparisons: " << maxComparisons << std::endl;

    // Delete a keyword
    root = remove(root, "apple");

    // Display the data in ascending order after deletion
    std::cout << "Ascending Order (After Deletion):" << std::endl;
    inorderTraversal(root);

    // Clean up memory (optional)
    // TODO: Implement a function to delete the entire tree

    return 0;
}
