#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>

struct Student {
    int rollNumber;
    std::string name;
    std::string division;
    std::string address;
};

// Function to add a new student record
void addStudent(std::ofstream& file) {
    Student student;

    std::cout << "Enter Roll Number: ";
    std::cin >> student.rollNumber;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

    std::cout << "Enter Name: ";
    std::getline(std::cin, student.name);

    std::cout << "Enter Division: ";
    std::getline(std::cin, student.division);

    std::cout << "Enter Address: ";
    std::getline(std::cin, student.address);

    // Write the student record to the file
    file.write(reinterpret_cast<const char*>(&student), sizeof(Student));

    std::cout << "Student record added successfully." << std::endl;
}

// Function to delete a student record
void deleteStudent(std::fstream& file) {
    int rollNumber;
    bool found = false;

    std::cout << "Enter Roll Number of student to delete: ";
    std::cin >> rollNumber;

    // Create a temporary file
    std::ofstream tempFile("temp.dat", std::ios::binary);

    // Read records from the original file and copy to the temporary file, excluding the record to be deleted
    Student student;
    while (file.read(reinterpret_cast<char*>(&student), sizeof(Student))) {
        if (student.rollNumber != rollNumber) {
            tempFile.write(reinterpret_cast<const char*>(&student), sizeof(Student));
        } else {
            found = true;
        }
    }

    // Close the files
    file.close();
    tempFile.close();

    // Delete the original file
    std::remove("students.dat");

    // Rename the temporary file to the original file name
    std::rename("temp.dat", "students.dat");

    if (found) {
        std::cout << "Student record deleted successfully." << std::endl;
    } else {
        std::cout << "Student record not found." << std::endl;
    }

    // Reopen the file for subsequent operations
    file.open("students.dat", std::ios::in | std::ios::binary);
}

// Function to display the details of a student
void displayStudent(std::fstream& file) {
    int rollNumber;
    bool found = false;

    std::cout << "Enter Roll Number of student to display: ";
    std::cin >> rollNumber;

    // Read records from the file and search for the matching roll number
    Student student;
    while (file.read(reinterpret_cast<char*>(&student), sizeof(Student))) {
        if (student.rollNumber == rollNumber) {
            std::cout << "Student Details:" << std::endl;
            std::cout << "Roll Number: " << student.rollNumber << std::endl;
            std::cout << "Name: " << student.name << std::endl;
            std::cout << "Division: " << student.division << std::endl;
            std::cout << "Address: " << student.address << std::endl;
            found = true;
            break;
        }
    }

    if (!found) {
        std::cout << "Student record not found." << std::endl;
    }
}

int main() {
    std::fstream file("students.dat", std::ios::in | std::ios::out | std::ios::binary);

    if (!file) {
        std::cerr << "Error opening file." << std::endl;
        return 1;
    }

    int choice;
    do {
        std::cout << "----- Student Information System -----" << std::endl;
        std::cout << "1. Add Student" << std::endl;
        std::cout << "2. Delete Student" << std::endl;
        std::cout << "3. Display Student Details" << std::endl;
        std::cout << "4. Quit" << std::endl;
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                addStudent(file);
                break;
            case 2:
                deleteStudent(file);
                break;
            case 3:
                displayStudent(file);
                break;
            case 4:
                std::cout << "Quitting..." << std::endl;
                break;
            default:
                std::cout << "Invalid choice. Please try again." << std::endl;
                break;
        }

        std::cout << std::endl;
    } while (choice != 4);

    // Close the file
    file.close();

    return 0;
}
